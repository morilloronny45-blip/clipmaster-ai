# ClipMaster AI — MVP

Esta primera versión permite:
- Subir un video local o pegar un enlace público compatible con `yt-dlp`.
- Crear segmentos consecutivos de 30, 60 o 90 segundos.
- Descargar cada segmento en MP4.

**Importante:** esta versión todavía no detecta automáticamente los momentos más interesantes con IA. Divide el video en segmentos consecutivos. La compatibilidad con enlaces de YouTube, Facebook y TikTok depende de que `yt-dlp` pueda acceder al contenido y de las condiciones de cada plataforma. No evade videos privados, DRM ni restricciones de acceso.

## Requisitos
- Python 3.10+
- FFmpeg y FFprobe instalados y disponibles en PATH.

## Ejecutar
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Abre http://127.0.0.1:5000

Para usarlo públicamente hace falta desplegar el servidor en un hosting que permita FFmpeg, almacenamiento temporal y trabajos de video largos. No publiques el servidor sin añadir autenticación, límites de uso y limpieza automática de archivos.


## Instalar en Android como aplicación
Este proyecto incluye una PWA instalable. Primero debe desplegarse en un dominio con HTTPS:
1. Instala Python, FFmpeg y FFprobe en el servidor.
2. Instala dependencias con `pip install -r requirements.txt`.
3. Ejecuta la aplicación detrás de un servidor WSGI (por ejemplo Gunicorn) y configura HTTPS.
4. Abre la dirección HTTPS en Chrome para Android.
5. Usa el botón **Instalar app** o el menú de Chrome > **Instalar aplicación** / **Añadir a pantalla de inicio**.

La PWA usa la interfaz del teléfono y puede abrirse como aplicación independiente. El procesamiento de video sigue ocurriendo en el servidor; no funciona sin conexión. Este paquete no es un APK nativo y todavía requiere alojamiento público para que el teléfono pueda conectarse.
