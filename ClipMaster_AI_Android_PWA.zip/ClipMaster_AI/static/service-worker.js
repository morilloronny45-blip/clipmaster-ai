const CACHE = "clipmaster-shell-v1";
const SHELL = ["/", "/static/style.css", "/static/manifest.webmanifest"];
self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)));
  self.skipWaiting();
});
self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
  );
  self.clients.claim();
});
self.addEventListener("fetch", event => {
  const req = event.request;
  const url = new URL(req.url);
  // Do not cache API calls or generated video downloads.
  if (req.method !== "GET" || url.pathname.startsWith("/api/") || url.pathname.startsWith("/download/")) return;
  event.respondWith(
    fetch(req).then(response => {
      if (response.ok && url.origin === self.location.origin) {
        const copy = response.clone();
        caches.open(CACHE).then(cache => cache.put(req, copy));
      }
      return response;
    }).catch(() => caches.match(req).then(hit => hit || caches.match("/")))
  );
});
